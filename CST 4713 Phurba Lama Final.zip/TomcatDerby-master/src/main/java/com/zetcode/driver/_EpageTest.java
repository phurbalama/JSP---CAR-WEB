package com.zetcode.driver;

import com.zetcode.bean.EPages;

public class _EpageTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EPages x = EPages.find("citychart");
		System.out.println(x);
	}

}
