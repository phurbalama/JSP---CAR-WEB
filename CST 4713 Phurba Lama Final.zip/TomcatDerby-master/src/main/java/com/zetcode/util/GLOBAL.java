package com.zetcode.util;

public class GLOBAL {
	public static final String DATA_SOURCE = "java:comp/env/jdbc/testdb";
	
	public static final String DB_URL = "jdbc:derby://localhost:1527/carsDB"
			+";user=app;password=app";
	
	public static final String ACTION = "action";
	public static final String IS_AUTHORIZED = "isAuthorized";
}
